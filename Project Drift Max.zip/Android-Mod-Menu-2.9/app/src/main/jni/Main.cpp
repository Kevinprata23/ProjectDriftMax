#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"

#include "KittyMemory/MemoryPatch.h"
#include "Menu.h"

#define targetLibName OBFUSCATE("libil2cpp.so")
//#define targetLibName1 OBFUSCATE("libunity.so")

#include "Includes/Macros.h"

struct My_Patches {

    MemoryPatch Coins, Cars, Archievment, RemoveAds;

} husnimods;

bool feature1, feature2, feature3, feature4, feature5, feature6, feature7, feature8, feature9, feature10;

// Hooking examples.




// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename

    do {
        sleep(1);
    } while (!isLibraryLoaded("libHusniMods.so"));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only.



#else //To compile this code for armv7 lib only.

    husnimods.Coins = MemoryPatch::createWithHex("libil2cpp.so", 0x7BF21C,"0201E0E31EFF2FE1");
    husnimods.Cars = MemoryPatch::createWithHex("libil2cpp.so", 0xD6282C,"0000A0E31EFF2FE1");
    husnimods.Archievment = MemoryPatch::createWithHex("libil2cpp.so", 0xB0689C,"0000A0E31EFF2FE1");
    husnimods.RemoveAds = MemoryPatch::createWithHex("libil2cpp.so", 0xA1BD320,"0000A0E31EFF2FE1");
 /*   husnimods.Block = MemoryPatch::createWithHex("libil2cpp.so", 0x892D8C,"0100A0E31EFF2FE1");
    husnimods.Attack = MemoryPatch::createWithHex("libil2cpp.so", 0x60C368,"0100A0E31EFF2FE1");
    husnimods.Auto = MemoryPatch::createWithHex("libil2cpp.so", 0x6BB1C8,"0100A0E31EFF2FE1");
    husnimods.Evey = MemoryPatch::createWithHex("libil2cpp.so", 0x6B51C8,"0100A0E31EFF2FE1");
    husnimods.Long = MemoryPatch::createWithHex("libil2cpp.so", 0x6B5A2C,"01A0A0E31EFF2FE1");
    husnimods.Stop = MemoryPatch::createWithHex("libil2cpp.so", 0xC77B0C,"0100A0E31EFF2FE1");
*/
    LOGI(OBFUSCATE("Done"));
#endif

    return NULL;
}

//JNI calls
extern "C" {

JNIEXPORT jobjectArray
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    //Toasts added here so it's harder to remove it
    MakeToast(env, context, OBFUSCATE("Modded by Husni Mods"), Toast::LENGTH_LONG);

    const char *features[] = {
            //OBFUSCATE("Category_NOTE"), //Note
            //OBFUSCATE("RichTextView_Tested Mod Menu By Husni Mods"),
            ("Category_MOD FEATURE"),
            ("0_ButtonOnOff_Unlimited Coins"),
            ("1_ButtonOnOff_Unlock Cars"),
            ("2_ButtonOnOff_Unlock Archievment"),
            ("3_ButtonOnOff_Remove Ads"),
            /*("4_ButtonOnOff_No Block"),
            ("5_ButtonOnOff_Unblokable Attack"),
            ("6_ButtonOnOff_Auto Play"),
            ("7_ButtonOnOff_Evey Hit And Combo"),
            ("8_ButtonOnOff_Longe Range Hit"),
            ("9_ButtonOnOff_Stop Enemy"),*/

            ("Collapse_About Me"),
            ("CollapseAdd_ButtonLink_Youtube_https://youtube.com/@husnimods"),
            ("CollapseAdd_ButtonLink_Telegram_https://t.me/Husnimods"),

            ("Collapse_My Friend"),
            ("CollapseAdd_ButtonLink_BANG EB_https://youtube.com/@bangeb294"),


            ("RichWebView_<html><div style=\"background-color: red; text-align: center;\">Copyright</div>"
                      "<marquee style=\"color: green; font-weight:bold;\" direction=\"left\" scrollamount=\"5\" behavior=\"scroll\">Modded by Husni Mods | 2022 - 2024</marquee>"
                      "</html>")
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        case 0:
            feature1 = boolean;
            if (feature1) {
                husnimods.Coins.Modify();
            } else {
                husnimods.Coins.Restore();
            }
            break;
        case 1:
            feature2 = boolean;
            if (feature2) {
                husnimods.Cars.Modify();
            } else {
                husnimods.Cars.Restore();
            }
            break;
        case 2:
            feature3 = boolean;
            if (feature3) {
                husnimods.Archievment.Modify();
            } else {
                husnimods.Archievment.Restore();
            }
            break;
        case 3:
            feature4 = boolean;
            if (feature4) {
                husnimods.RemoveAds.Modify();
            } else {
                husnimods.RemoveAds.Restore();
            }
            break;
      /*  case 4:
            feature5 = boolean;
            if (feature5) {
                husnimods.Block.Modify();
            } else {
                husnimods.Block.Restore();
            }
            break;
        case 5:
            feature6 = boolean;
            if (feature6) {
                husnimods.Attack.Modify();
            } else {
                husnimods.Attack.Restore();
            }
            break;
        case 6:
            feature7 = boolean;
            if (feature7) {
                husnimods.Auto.Modify();
            } else {
                husnimods.Auto.Restore();
            }
            break;
        case 7:
            feature8 = boolean;
            if (feature8) {
                husnimods.Evey.Modify();
            } else {
                husnimods.Evey.Restore();
            }
            break;
        case 8:
            feature9 = boolean;
            if (feature9) {
                husnimods.Long.Modify();
            } else {
                husnimods.Long.Restore();
            }
            break;
        case 9:
            feature10 = boolean;
            if (feature10) {
                husnimods.Stop.Modify();
            } else {
                husnimods.Stop.Restore();
            }
            break;
*/

    }
}
}

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}


JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    return JNI_VERSION_1_6;
}
