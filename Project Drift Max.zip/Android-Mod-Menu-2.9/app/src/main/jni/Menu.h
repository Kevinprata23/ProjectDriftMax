bool titleValid, headingValid, iconValid, settingsValid, isLeeched;

void *antiLeech(void *) {
    sleep(20);

    if (!titleValid || !headingValid || !iconValid || !settingsValid) {
        int *p = 0;
        *p = 0;
    }
    return NULL;
}

void setText(JNIEnv *env, jobject obj, const char* text){
    //https://stackoverflow.com/a/33627640/3763113
    //A little JNI calls here. You really really need a great knowledge if you want to play with JNI stuff
    //Html.fromHtml("");
    jclass html = (*env).FindClass(OBFUSCATE("android/text/Html"));
    jmethodID fromHtml = (*env).GetStaticMethodID(html, OBFUSCATE("fromHtml"), OBFUSCATE("(Ljava/lang/String;)Landroid/text/Spanned;"));

    //setText("");
    jclass textView = (*env).FindClass(OBFUSCATE("android/widget/TextView"));
    jmethodID setText = (*env).GetMethodID(textView, OBFUSCATE("setText"), OBFUSCATE("(Ljava/lang/CharSequence;)V"));

    //Java string
    jstring jstr = (*env).NewStringUTF(text);
    (*env).CallVoidMethod(obj, setText,  (*env).CallStaticObjectMethod(html, fromHtml, jstr));
}

extern "C" {
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_setTitleText(JNIEnv *env, jobject thiz, jobject obj) {
    setText(env, obj, OBFUSCATE("<b>HUSNI MODS</b>"));

    titleValid = true;
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_setHeadingText(JNIEnv *env, jobject thiz, jobject obj) {
    setText(env, obj, OBFUSCATE("<b><marquee><p style=\"font-size:30\">"
                                      "<p style=\"color:green;\">Drift Max v9.0 | Youtube : Husni Mods</p>"
                                      "</p>"
                                      "</marquee></b>"));

    headingValid = true;
}

JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Icon(JNIEnv *env, jobject thiz) {
    iconValid = true;

    //Use https://www.base64encode.org/ to encode your image to base64
    return env->NewStringUTF(
            OBFUSCATE("iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAABHNCSVQICAgIfAhkiAAAGXpJREFUeJztnXl0VFW2/z/n3qpKFZCkyBySMKchUVRsBRqU1vYn4NCCysKWVltUQBx4oviwRQX9ATat+GChCDh0Q4O+bvupiKDoc2AQA9hxjCBzogQykKoQMlTVvXe/P5K6JBAyB1rlu1atpKru2fuc791nn3P22ecWnMEpgTrdFTgOccCLwEgApRSJiYkMGzaMSy65hIyMDLp06YJSigMHDrBjxw4+/vhj3nvvPQ4dOoSIhOW8DdwOFJ6eZpyI0020AzgCeNxuN5s2baJ3795tInj//v0MHjyYiooKgCogGgi2ifAWQDtNegOA3HHHHSG/3+/x+/0cOnSozUgG6N69O/n5+fj9fvx+v3vSpEkBQDhNZJ9Ki/4N8EHfvn3Jyso6hWpPxODBg/n2228BrgDePRU6T4VFTwJk3rx5H/j9/tNOMsDmzZvx+/0sXLjwHaqt/L721tmeFp0G5E2fPp0HH3ywHdW0HvPnz2fmzJkAvYE97aGjvYiWlJQUcnJy2kl8++D8889n79690A68tLXAm4C/+f3+NhZ7auH1egEmAC+0lcy2JFrS0tL4+uuv21Dk6cMFF1zA7t27oY04aiuiJScnh5SUlDYS9++BQ4cO0bdvX2gDnlorIAY4/GN3FY2hxpUkAQUtldGa6d1v+BmQDFDTxkPAb1sqo6VET1BKffBzIDkMv9+PpmlvAVNaUr4lruM3SqkPfD5fS/T96BETE4NlWb+lOnDVZDSX6Dig6OdkyfWhxmcnU+1OmoTmEi0/d5LDqCG7yfw1h+gzJB+H5pDd1MFQaibvZ1ALeXl5UB2UahRNIfrO9PR04uLiWlWpnyKioqLo378/wLTGrm2K2Z9xGY2gKS6kMYv+tyZZRFBKYRoGQgh/RJN6cZujhqMGlTdEdHqPHj3atEJNgU2eabJ06VLKysoIBAInXGdZFlBtTbGJCXT3dqV7VGztDdpTiszMTIBzT/Z9Q+Z+Wqw5GAySnJyMaZpA9U74V199RVpaWp3rDMPgkUceYcmSJThE2OrNZNzRnXxpmpyuxVRDLuRkFn3fk08+2W4VOhkshBEjRoBl8VWfPjwem0gHHJxzzjknWKplWSxevBgRoTj5fHp7HKQP7o+IEBMTQ3JycjjMecqsfNGiRQAz6vvuZBZ9yqzZsiwcDgfl5eUkd0kGAQ1F2YOPEvzHC8TnHsQA1q1bx8CBA+1ypaWldOvWDYDvu6WjX38DqfPnYlmhOvI1TSMtLY3NmzfTqVMnLMvCsix0XW+X9pzMquuz6MueeeaZdqlEGJZlISKICEVFRURHR5OcnGwPJxZC5X+Mx7Is4mvKDB8+3C4vIlx//fX2+4/FQdTf38FyGvXqys3NJSUlBa/Xy7Bhw2z/LiJ2XdoKS5cuBbjx+M/rI/p/b7vttjZTXB90XWfPnj3ExMTQr1+/ehvavVsa7kASBzUHDocDgIqKCtsis7OzmTdvHkopUiJd/L6zDz1wzJCUUui6TkxMDA6HA6UUIsK2bduIj4/H6/Uyffp0NE1rU6LHjBkD8Mrxn59g4hkZGfLpp5+2meLaME2Tzz77jCuuuALLsuzG1wvlJDetJ/915CBP5P1ATEwMbrebvLw8nE4nkZGRrFixgpycHMpfXsGzhd+j4yAkda1a0zTi4+OZOnUqTqcTwzDIz8/n1Vdf5eDBg2iaxtSpU5k2bVqbuZPLLruMf/3rX3W4PZ7ooN/vd7aJtlrQNI0333yTW2+91XYZmqZx7bXXMmjQIB5++GFCoWO+NXwDXA4HhmkiVHdzXdcpLi4mEAiQlJSEUop+/fqRlZVFx44dKSgs4Lprr2PTpk223kcffRSv12u7C6UUlmXRv39/gsEg27dv5/7778ftdtv5e0q1fofveF99vMQ2HwRDoRAJCQl2wuLkyZNxuVxomsbMmTNxOBxERUWxb98+ABwOB9OmTeOWW26hT58+fPzxx7zzzjssWLCAqqoq9u3bx4svvsjs2bMBmDBhAvn5+bz99tsUFxejadXesFevXuFgPSJCv379uPnmm9F1HcOotvphw4aF57+43W4sy+Lw4cO2jNagIaKdd911V3DOnDmtVgLVbmLnzp0MGTKEbt26cf/99xMTE2N317DVbN26lVdffRWlFEopiouLgWo/Hh0dzahRo5g6dSqXXXYZwWCQ2NhYfD4fmqYRCoVYunQpEydOZOLEifzpT38CqgfAGTNmsHDhQqDassMWnZqayv79+/H7/axevZry8nLuvPNOLMuia9euFBUVUVRU1Gqy//znPzNnzpyOQAXUJbrC7/d7WiW9BpZlsXHjRkaOHMn8+fOZPHkyoVCIZ5991m50eXk5M2bMqOOjp02bxkMPPWTfhLfeeotx48YxZMgQNm3aZLsdqLb8p59+mqlTp2IYhm2J4VVl3759KS4u5sknn8TlctnuyO/3M3v2bAYMGMD69evRNI2CggISExMRES666CK2bdtmk90aN+L1eiuBDlCX6DZxGyJCbm4u5513HitXrmT06NGUlZWxfPlyLrjgAgYPHozH47FdSkpKCtu3b6eqqsr2weHGWZZFTEwMf/zjHykoKGD16tUcPnzYts6nn36aqKgoJkyYgM/ns8sppYiOjua2224jMzPTJux4/zt16lRycnJIT09HRDAMA13XyczMZPfu3Rw+fBigxdZd233YWl0ulxQWti5vOzz1SkpKYu7cuUyaNIny8nKCwSDx8fHs3r2bzMxM5s6dS0REBIFAAIfDgWEYHDlyhKeeeoqCggKbDE3TmDt3LrNnz8blcjFmzBhee+01TNPEMAy6dOlCUVERo0aNYunSpXY5p9NJp06deOKJJ4iMjLRnOPXVt7S0lAULFtg3OBQKEQwGSUpKoqqqig0bNtCvX78W8ZGamsrRo0frEB27cePG4pYKDCO8/M3IyOCbb74Bqn21iDB48GC6d+/OgAED7Hlt7XKWZTFt2jSWL1/O8OHD7RvgcrmIiopi//79fPDBB9x7771UVFTg9Xp5/PHHmTJlCnl5eRw4cICdO3fy+eefs3nzZrZt22bHS+CYn67tr8N1CFv622+/zdVXX43D4UDTNAzDID4+nu3bt7fIhXz33XcMHDgwFTgQLv0/fr//upbRewzdu3enrKzMnqqFCezQoQNz5sxB13VKS0vx+/34fD5yc3Px+Xxs3769zvSupKQETdOYMmUKy5cvr0MYYA+c4Vd8fDz9+/cnOTmZLl264HK5mDFjBkVFRVx88cUUFhaSn59vL3zCMsL+XkRwOp3ous6mTZsYMGAAIkJsbCylpaWsWrWKiy66yC7XHHi93veBYWHNrSJZRMjOzranU+FX2HLmzZtHt27dmD59OpZlERsbi9fr5ZNPPsGyLLKyskhNTcXtdhMXF4eu61iWxapVqzhy5AgejwfTNHE6q6f4t9xyCy+99BJwzH/WXgCJCOnp6cTGxpKZmcnBgwftuh5PVPj9Sy+9xLhx4+yVanjgfPnllxk5cmSdsaOZuByOuY5WDYSmaRIbG8uUKVOYP3++HT9WSuFyuXjmmWf43e9+R3p6OkVFRURERNjWCMeia2VlZfTq1Ytdu3ZhWRZxcXGEQiG7GzudTiZOnMjChQtxOp0nxCx0XbeJP3LkCNHR0ZSXl+PxeFBK8corr7Bx40Y+++wzysvL+fLLL20rP++888jJySEUCqGUsvWFQiE8Hg+dOnVi3759LbFoAKUBrV56jhkzBpfLxaxZs/B4PDidTjRN4/vvvyc+Pp677rqLmJgYjh49isvlqlO29ubCm2++yY033ohpmjaJYeLCf++77z6b5B49eqDrOg6HA5fLRd++fZkxYwZjx47liiuuAKoXIlB9M2666SZ+8Ytf8Mgjj1BcXMz+/fvtG75jx446ek3TxO12IyJUVlZSVlZGaWmp/X1TUdtd0bt3b/H7/c1+lZSUiN/vF6WU5ObmypdffikXXnihiIiYpikzZ86Up556SoLBoFAdmxPTNMU0TamqqhJAnnzySTFNU0RE+vbtK1u2bBGfzyfFxcWi67qEUVJSIkopCQQCIiJiWZZommbLVUrZ/7vdblm3bp1ommbrq6ysFLfbLSUlJbbsQCAglmWJZVkCiMPhEMuyRETkiy++EKfTKYZhiGEY0rNnT3E4HM3mqF+/fgI10bvLL7+8WXepNgYOHIimaaSmprJs2TLuvPNOoNptLFq0iEcffZQOHTqglLL/KqXCh3UYO3as3R337NlDz549gerja7UD/i+88AIiYltIIBAgEAjYU8pgMIhlWYRCIXtQ83q9tr6srCwGDRqEpmn2GFDH2oChQ4fadfnLX/7C6NGjeeyxxwDYtWsXhmGEj9M1Gddcc82xN3//+99bbNGA5OXliWmaEhsbK0VFRbZF79q1SwoLC6WsrEwqKiokFArZ340fP14AsSzLtjpAfD6f+Hw+mTx5sixdutS2sLi4OAFsi24IFRUVopSScePG2fpGjx4ta9asEb/fLz6fT5RStrX6fD4BZN26dba+xMREycrKkrPOOksCgYAEAgFJSEiQyMjIZnG0Zs2aY0vf7OzsZpPs8/lk0aJFopSSYDAopmmKUsomM4ywWwiTGf4/JiamJihX7QYCgYBNtN/vl8TERCkuLhYxDSm1RPAgy2LTJE53i1FmiBEy5GBhkWz+LFte+cdr8tobr4sZDNryANm2bZutz+12y6FDh8Tn88nevXulW7du9rWvv/66AHL06FGbaE3TxDAMeemll6Rr165iGIZUVFTUqWNTXl9//bVA9clVEhISmtUdqGaIe+65h+uuuw5d1+vMg4+/rqSkhOLiYnr27GlH00pKSuqM4BUVFei6bk/RCgoK8Hq9iECEAgyY5zuIw1JERTqoADJ6dCfg84HuYO/hEipDBu4aWWDvTANQVVWFy+VCRHj99dcZO3asXb9FixahaRoREREAdnTPNE1uueUW3n33XXsWomka69ev55JLLmkSTzExMcfeHDhwoMVuIxQKSSgUkrS0tDqD18GDB0XXdXE6nXa3D1tL2E3ExcWJiIhhGLJu3Tpxu92SnJwsXq/XHshCpilVlikK5P03V8n3RUXiq6yQe+6+WzSlRAeJjfbKshV/E8Ooll/TXe0eFLbw8OCdmZkpO3bssOsSERFh18+yLDEMQwDRNE2qqqpkx44d0r17dzFNUy666CKJjo5uMk/5+fnHXMfnn3/ebKKXL18ugBiGIcFgUPr06SN9+/YVwzDENE1ZvHixTJkyxXYz4WtFxJ6FPPDAAzYRpmnKV199Jfn5+VJVVVXHn5eXl9s3NSzjZAiFQtK5c+c6+gKBgGiaJiUlJVJaWipKKamsrBTTNMUwDFFK2TOMUCgku3btkvT0dFFKyaBBg8QwDOnfv78Eg0HbfTTXdWgALUlgvOOOOzjnnHNQSvHggw/Sq1cvwnuNIsJzzz3H7bffbnfB8KoO4IcffgDguuuuqxP6PPvss0lKSrI3BsLfRUVFoZTihhtusOWf7NWxY0d8Ph8OhwPLsjBNky+++IKBAwfW2Yy96aabuPDCC/F4PHZsOzwfT09P5+abbyY3N5esrCwqKirYuHEjH330kb0OCM92GkNNImS1j16/fn2zp3jBYJD3338fqM5nSE1NZcmSJTZBOTk5JCYmArBz5077pgCsXLkSgCFDhjSo4/g9xVWrVp0wJTvZ9eGAVO3PkpKSOHToEAsWLCAjI4PU1FSioqLQNA2n02nLllrZUoMHDyY6OhrDMLjyyisJBqvP7G/ZsoVf/epXjfL0ySefADVEr1u3jlmzZjVaCLAjYACxsbFYlsX48eN5/vnnWbx4MWvXrrV3q8MNXLZsGdnZ2XUGu3BD6g1fiqBMQDMQ5UCZoHQF4iOoOqLhQq8KIZqO4QoSwEmnoA6GYHkUmlSC6UHVXYTaO+N/+MMfGmxjuE66rrN27Vq8Xi+rVq1i+PDhdp3DvaSxWPXatWurZdYIlHCQuzGEu0xCQgLBYJDdu3eTkJDAY489xrPPPsvKlStJSUkhPj6e5ORkO7h0PKGdO3c+4XPBwrKA0FEOfpZF3KBhKA7j+yibyP83iOKcr4ku0Im85ALyNm8E8ZE44EocVgjycjiYvZfOY8YQZQqGy8Hxtq+UCickNhkiwjPPPMPs2bMpLy+nrKyMtLQ0Ro0axfPPP98o0fHx8YRCoepYx/FhyIaglKKoqMi2yoEDBxIdHc3ixYtJS0tjxIgRnHvuuaSlpdWJV9QOazaiAStYTscbJhMwhL1XXYs+4V52jrwKsyQB5clj769vInjnncSffxV5gwahVRxEv3Qcbj2ewK5vsQDdbF5MoiFMnjwZEWHFihVMnz69WXkg4WnvyR3eSaCUIhAI2MrCgRbTNNm2bZtNan1L3MYhaKIwNYM9dw2l619eo0NhJ5zmD3Tf/R2ui+Nxy8V4dj9LfhS4dQfpLz9O6QcHOPLH0UTdO4GIbz/F0DTQNVz1aDAMo1n1UkrhdDp54IEHGD9+vN1D68yPm4Cw3b/Z1AK1rVRE6NOnD/3790fXdTv82RpYokAEd+WFWP//P0h9bwXOQALuFxdQetZQis69nMBzDyG6n8rR15M/6h5iRg4k7k9LiOifiZl/CEFDqN+i4+Pj+fDDD+1FSVMxffp0u/2apjFixIim7iX+LxyLR8d9+umnRRkZGY2WEhF8Ph89e/YkGAzy3HPPcf/997NixQquvvrqJnercFKLQjCVhR5yIE4Ly9TQtXL8YtFR3KA0DGXgKYvAihRCStBDoAOGFsBhuLGcoJkmpnYEzexMyGUQIU67dRYWmmjVAyo6iElHj4cD+fkgYJgmDmfDVm6aJr/+9a/55ptv0DTN3rhtyLD27NnDL3/5yzTgB/uqmlhAk0gKd51AIMDevXvJyMjg8OHDKKWadJfD5U3TJKDAHVCEIgLoVpsnSQFgKAunpdPBqZMC7HVqaCEL0TXunnQXs2Y+Do7GY/LhPUSp2X1pDGlpaZSVldXdBaeJuyxh1xEbG0t5eTlerxen08mBAwcaLRvGWWedZV/vcoI3BJbTTXGoCqUUERERbZZ4qGkalZWVaLqDeKdObkxXPvO4uez7HCRoEdQVuqV46+3Vjc7rpWYf0ePxNKm9tdMNaveXKsDdWOHa20/nnXcewWCQ1atXN1gmGAzi1J1UVR4luVcaEQHA6eEyPcT/xEdSmjSE/77xUh5+8D/Zs2dPTTCp7TI8165dy+9//3sGX/Nbyv7xGhmDrqCwqogtLgfDC37AJIKrrrqqUStVSjFp0iSuvPLKpqqutMvW+tB59913B8M5bY3hjTfeYNy4cXYaV0PbYZZlcfutt/LGmrVEmRoKiy2pqSRZOlHr3+Wd3Tu56spr2JK1mfT0dKDlSSv1QWq2o7p06YKuFEdDIfbffCvdN3xClRZF50NfoQwaPZIRvvlSk6TZEJ5++mlmzZoVCRyFViQ5hjdkgTpZQvXBMAzi4uJw4KC/U/goLgnNioLvsxlz+Ug+2PAhW/ZsJyU6ptVpWI3VOSOpK8VmFf4DeciQS1kdspjw/X7eWLemzomChlB7dXwyHJ/kePxQGwKaNCKJCB6Px95hbggOhwPN4cSyQqyNO4uQXkDgzWeZPPYPvL3+PUpKStB1vd3Pmui6zq7ifC6++GKiklNIVYpChMn/+RCDBg1qsv4m9rY6wk5g6Oyzz5ZwfnFDCMcyvvvuuzoB9vpgmiZllWWck9qHri6TLVE9mNC1Eyuzv6Gg4Ac7Zba9LLk2DMNA0zQqKiq4Y/xEFi5+juRO0QRV4+6gqRg+fDhbtmxpMBEdmuk+mtrVLRMCVojUxHhMUejofPH1NtJSezSpK7YHRAwspeEyNMxmr5FPjvoODNXXuqvCYczGEI7GNQWaDh6nk8MlfooKCyksLiAttTqn43SQDKCUA522JXnVqlVQ/aTfurpOcn27HX+r7QdPhas41WjO8TeAh19++eV2qUjTo3g/Pvzzn/8EqPck7L/dEeUfM1pyRBkgY8CAAe1SoZ8iatIPLjzZ94313zNW3UQ09syOMw9GaQO0xYNRAB4IZ7ufwYkYMWIEwBONXdfUoV/27dtH586dW1WpnxqOHj1KamoqNIHHM49jawWa8zi2Mw8YbCGa+4DB5q59e9Qo+FmjhoM+zSnTXKL3A2Oau9X+U0JNDP52YGdzyrUkmvOaZVlTf45kx8bGYprmTKDZ8YnWBBx+C7z1c/HZNe7iRuC/W1K+tZGdBKDgp052DcndgLyWymhtILgQUF6v137Oxk8JPp+v9uyixSRD2/2Ek+rdu3ejeRE/Jlx66aXhw6b/Vj8PEsZkYMGP3ZXUWPE04M9tJbPdfsKpZ8+eZGdnt5P49kGtX4Vrc17aa7NO7d279xder5clS5a0k4q2w1//+le8Xi/ffvttP9rJ+NpzV3QXoKZNm3af1+vlhRfa7Gen2gzLli3D6/Vy3333TaOa4G/aS9ep3LgbDrx7/vnn8+GHH55CtSdi2LBhbN26FeAaoOHEwTbCqdznXweo7Oxs5fV68Xq99uPTTgXmzZtHWO/WrVsV1UZ2SkiG0//jvh2onot3jIyMZMOGDXWe39Ea5OXlMXTo0HCGaAWQSE3C4enA6Sb6eHQF/gYMherEmh49enD11VczdOhQevToQXx8PEopCgsL2bdvHxs2bGDNmjXs27ev9qGnTVT/tmLu6WnGGZw2/B8O8klBUbz1AQAAAABJRU5ErkJggg=="));
}

JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_IconWebViewData(JNIEnv *env, jobject thiz) {
    iconValid = true;
    //WebView support GIF animation. Upload your image or GIF on imgur.com or other sites

    // From internet (Requires android.permission.INTERNET)
    // return env->NewStringUTF(OBFUSCATE("https://i.imgur.com/SujJ85j.gif"));

    // Base64 html:
    // return env->NewStringUTF("data:image/png;base64, <encoded base64 here>");

    // To disable it, return NULL. It will use normal image above:
    // return NULL

    //return env->NewStringUTF(OBFUSCATE_KEY("https://i.imgur.com/SujJ85j.gif", 'u'));
    return NULL;
}

JNIEXPORT jobjectArray JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_settingsList(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_Settings"),
            OBFUSCATE("-1_Toggle_Save feature preferences"), //-1 is checked on Preferences.java
            OBFUSCATE("-3_Toggle_Auto size vertically"),
            /*OBFUSCATE("Category_Logcat"),
            OBFUSCATE("RichTextView_Save logcat if a bug occured and sent it to the modder. Clear logcat and reproduce bug again if the log file is too large"),
            OBFUSCATE("RichTextView_<small>Saving logcat does not need file permission. Logcat location:"
                            "<br/>Android 11: /storage/emulated/0/Documents/"
                            "<br/>Android 10 and below: /storage/emulated/0/Android/data/(package name)/files/Mod Menu</small>"),
            OBFUSCATE("-4_Button_Save logcat to file"),
            OBFUSCATE("-5_Button_Clear logcat"),*/
            OBFUSCATE("Category_Menu"),
            OBFUSCATE("-6_Button_<font color='red'>Close settings</font>"),
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    settingsValid = true;

    return (ret);
}
}
